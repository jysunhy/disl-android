/*
 * @(#)Graph.java	1.13 06/29/98
 * A simple two-value bar graph to use in reporting pages
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1997,1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 */

import java.awt.*;

public class Graph extends Canvas
{
    private final static int MAX_DECIMALS = 8;
    
    private Color barColor;
    public int barColorRgb;
    private double base[];
    private String baseLabel[];
    private int baseLabelWidth;
    public int decimals = -1;
    private String decimalPad = "0000000000";
    public int digits = 3;
    private Font font;
    private FontMetrics fontMetrics;
    public String fontName;
    public int fontSize = 10;
    /*
     * assumed, not measured so that we can derive from Canvas instead
     * of from Container
     */
    private int insetWidths = 5;
    private String labels[];
    private int labelWidth;
    private int maxIndex = 0;
    private double maxValue;
    private double peak[];
    private String peakLabel[];
    private int peakLabelWidth;
    public int spacing = 2;
    private boolean valid;

    public Graph(String astring[], double ad1[], double ad2[],
	int decimals, int digits)
    {
        fontName = "TimesRoman";
        if (astring.length != ad1.length || ad1.length != ad2.length)
        {
            valid = false;
            return;
        }
        valid = true;
	if (decimals > MAX_DECIMALS)
	    decimals = MAX_DECIMALS;
	this.decimals = decimals;
	this.digits = digits;
        labels = astring;
        base = ad1;
        peak = ad2;
        baseLabel = new String[astring.length];
        peakLabel = new String[astring.length];
        maxValue = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < ad2.length; i++){
            if (ad1[i] == Double.NaN || ad1[i] < 0.0)
                ad1[i] = 0.0;
            if (ad2[i] == Double.NaN || ad2[i] < ad1[i])
                ad1[i] = ad2[i] = 0.0;
            if (ad2[i] > maxValue){
		maxIndex = i;
                maxValue = ad2[i];
	    }
            baseLabel[i] = makeValueLabel(ad1[i]);
            peakLabel[i] = makeValueLabel(ad2[i]);
        }
    }

    /*
     * Do it by hand instead of using java.text.DecimalFormat
     * so that it will be viewable on older API1.0.2 systems
     */
    private String makeValueLabel(double d1)
    {
	int decimals;
	if (this.decimals < 0){
	    /*
	     * Define number of decimal places per each number formatted
	     * according to desired number of significant digits
	     */
	     decimals = digits - (int) (Math.log(d1) / Math.log(10) +8) + 7;
	    if (decimals < 0)
	        decimals = 0;
	    else if (decimals > MAX_DECIMALS)
	        decimals = MAX_DECIMALS;
	}else{
	    /*
	     * decimals overrides digits
	     */
	    decimals = this.decimals;
	}
	double decimalScale = Math.pow (10.0, decimals);
        double d2 = Math.round(decimalScale * d1);
        String string = Double.toString(d2 / decimalScale);
	String pad = decimalPad.substring (0,decimals);
        int i = string.indexOf(46);
        if (i < 0)
            return string + "." + pad;
        string = string + pad;
	if (decimals == 0)
            return string.substring(0, i + decimals);
	else
            return string.substring(0, i + decimals + 1);
    }

    private void setWidths()
    {
        for (int i = 0; i < labels.length; i++)
        {
            int j = fontMetrics.stringWidth(labels[i]);
            if (j > labelWidth)
                labelWidth = j;
            j = fontMetrics.stringWidth(baseLabel[i]);
            if (j > baseLabelWidth)
                baseLabelWidth = j;
        }
	peakLabelWidth = fontMetrics.stringWidth(peakLabel[maxIndex]);
    }

    public void paint(Graphics g, Dimension rectangle)
    {
        if (!valid)
            return;
	if (barColor == null)
	    barColor = new Color (barColorRgb);
        if (font == null)
        {
            font = new Font(fontName, 0, fontSize);
            fontMetrics = g.getFontMetrics(font);
            setWidths();
        }
        g.setFont(font);
        int i1 = (rectangle.height - spacing) / labels.length - spacing;
        double d = (double)(rectangle.width - insetWidths - labelWidth
	    - peakLabelWidth - 4 * spacing) / maxValue;
        int j1 = spacing;
        for (int k1 = 0; k1 < labels.length; k1++)
        {
            int i2 = labelWidth + 2 * spacing;
            int j2 = (int)(d * peak[k1]);
            int k2 = (int)(d * base[k1]);
            int i3 = i2 + k2 - baseLabelWidth - spacing;
            if (i3 < spacing)
                i3 = spacing;
            int j3 = i2 + j2 + spacing;
            int k3 = j1 + (spacing + i1) / 2 + 1;
            g.setColor(Color.black);
            g.drawString(labels[k1], spacing, k3);
            g.setColor(barColor);
            g.drawRect(i2, j1, j2, i1);
            g.drawRect(i2 + 1, j1 + 1, j2 - 2, i1 - 2);
            g.fillRect(i2, j1, k2, i1);
	    //if (k2 > 0){
	    if (i3 >= i2){
		g.setColor(Color.white);
		g.drawString(baseLabel[k1], i3, k3);
	    }
            g.setColor(Color.black);
            g.drawString(peakLabel[k1], j3, k3);
            j1 += i1 + spacing;
        }
    }

}//end class
