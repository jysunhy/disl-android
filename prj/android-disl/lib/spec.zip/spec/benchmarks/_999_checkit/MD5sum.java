
/*
 * Discovered that ifs.available was Unreliable method of 
 * getting data over the network. So a more robust mechanism
 * was implemnted. This was checked by comparing size of the
 * file vs. number of bytes read. So appropriate code changes were made.
 * getSpecBasePath() was removed.
 * Kaivalya & Don McCauley Fri Jun 19 16:12:33 CDT 1998
 *
 * Latest changes returns String of computed checksum to caller
 * so it can be compared user can be warned of mismatch.
 * kaivalya & Don Wed Jun 17 13:32:28 CDT 1998.
 *
 * MD5sum.java   Version 2.1 Wed Jun 17 13:32:28 CDT 1998
 * Testing on browsers showed that full-path name was requires.
 * So, Walter suggested using "getSpecBasePath" and Don implemented
 * this. -- Kaivalya
 *
 * Copyright (c) 1996 IBM Corporation, Inc. All rights reserved.
 *
 * Permission to use, copy, modify, and distribute this software
 * and its documentation for NON-COMMERCIAL purposes and without
 * fee is hereby granted provided that this copyright notice
 * appears in all copies. Please refer to the file "copyright.html"
 * for further important copyright and licensing information.
 *
 * IBM MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. IBM SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * Kaivalya M. Dixit/Don McCauley/Randy Heisch IBM Corp. - Austin, TX
 *
 * SPEC development version @(#)MD5sum.java     2.10 Mon Jun 15 09:06:49 CDT 1998.
 */

package spec.benchmarks._999_checkit;

import java.security.*;
import spec.io.*;
import java.io.*;
import java.lang.*;
import java.util.*;

class MD5sum {

MD5sum() { ; }

   String read(String fname) {   // filename:, class, validity or source file
   int n, act;
   n = act = 0;                                //  kmd/dwm 6/19/98

//    String prefix = "./spec/benchmarks/";     // relative path   kmd/dwm 6/19
   String s = new String() ;

//   if (spec.harness.Context.getSpecBasePath() != "")    // kmd/dwm 6/19
//     prefix = spec.harness.Context.getSpecBasePath() + "spec/benchmarks/"; // dwm 6/2/98

// String filename = prefix + fname;     // kmd/dwm 6/19
   String filename =  "../" + fname;  

   spec.io.FileInputStream ifs = null;   // kmd/dwm 6/19
   MessageDigest   md5 = null ;
   byte buffer[];

   try { md5 = MessageDigest.getInstance("MD5"); }
   catch (java.security.NoSuchAlgorithmException  jse) {};
   
   try {
	  //  kmd/dwm 6/19/98
          ifs    = new spec.io.FileInputStream(filename);  // read class, validity or source file
//        n      = ifs.available(); // returns # of bytes in the stream kmd/dwm 6/19
          n      = (int)ifs.getContentLength(); // Reliable # of bytes in the stream
          buffer = new byte[n];
          DigestInputStream dis1 = new  DigestInputStream( ifs,  md5 );

// added reliable method of reading the correct number of bytes kmd/dwm 6/19	  
	  int bytes_read;
	  while ( (bytes_read = dis1.read(buffer, act , (n - act))) > 0){
	     act = act +  bytes_read;
	  }

//        act = (int)dis1.read(buffer, 0, buffer.length);   kmd/dwm/  6/19

          md5.digest (buffer);                    //  compute MD5 checksum
          String d1 = new String(md5.toString());
	  StringTokenizer token2 = new StringTokenizer(d1, "<>");  // strip extra stuff

	  int j = 0;
	  while (token2.hasMoreTokens()) {
	    String s1 = new String (token2.nextToken());
  	    if ( j == 1 ) {                                         // add file name to checksum
//      	spec.harness.Context.out.println (fname + " :" + s1 + " : " + n);
        	spec.harness.Context.out.println (fname + " :" + s1 );
                String ss =  new String ("1" + fname + " :" + s1) ;  // add validation flage
//              String ss =  new String ("1" + fname + " :" + s1 + " : " + n) ;  // add validation flage
	        s = ss;        // add 1 and filename to computed string
	         }             // end if
	    j++;
	  }                    // end while
		
            }   // end of try

   catch (IOException ioe) {
          System.out.println("ERROR opening/reading "+filename);
          System.exit(1);
      };

   // release resources 

   buffer = null;
   try { ifs.close(); }       // close the input file stream
   catch ( java.io.IOException IOE ) {};
   ifs    = null;
   md5    = null;
   
   return  s;         // return computed checksum string kmd/dm 6/12/98
     
   }   // end of read

}      // end class MD5sum

