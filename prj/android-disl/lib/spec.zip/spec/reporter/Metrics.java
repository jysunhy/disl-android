/*
 * @(#)Metrics.java	2.2 09/14/98
 * Results for all runs of all benchmarks
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1997,1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 */

package spec.reporter;

import java.io.*;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public class Metrics{

///////////////////////////////////////
//class variable field declarations
///////////////////////////////////////
private static int maxBarWidth = 0;
private static int	digits = 3;
private final static int widthAdj1 = 80;    // SPEC ratio graph
private final static int widthAdj2 = -80;   // memory utilization graph

///////////////////////////////////////
//instance variable field declarations
///////////////////////////////////////
private double			baseMetric;
private Result			check;
private double			highestBase = 0;
private double			highestPeak = 0;
private String[]		name;
private double			peakMetric;
private ReportProps		props;
private Result[]		result;
private boolean			runFromHttp;
private boolean			runInHarness;
private boolean			useJavaGraph;
public boolean			valid;

///////////////////////////////////////
//constructor declarations
///////////////////////////////////////
public Metrics (ReportProps props){
    this.props = props;
    check = new Result ("_200_check", props);
    String s = props.get ("spec.results.commandLine");
    runInHarness = s != null && s.equals ("false");
    s = props.get ("spec.initial.cbase");
    runFromHttp = s != null && s.toLowerCase().startsWith ("http:/");
    this.valid = check.valid && runInHarness && runFromHttp;
    name = benchmarkList(props);
    result = new Result [name.length];
    for (int i=0; i<result.length; i++){
	result[i] = new Result (name[i], props);
        this.valid = this.valid && result[i].valid;
    }
    calculate();
    if (maxBarWidth <= 0){
        maxBarWidth = props.getInt ("spec.report.maxBarWidth");
        if (maxBarWidth <= 0)
            maxBarWidth = 300;
    }
}

///////////////////////////////////////
//class method declarations
///////////////////////////////////////
/*
 * Simplistic number formatter to avoid bug in Linux JDK with
 * NumberFormat
 */
public static String format (double x){
    int n;
    String s;
    String formatted;
    try{
        if (x < 0.01){
	    formatted = "n/a";
        }else if (x < 0.1){
            n = (int) (1000 * x + 0.5);
            s = Integer.toString (n);
            formatted = ".0" + s;
        }else if (x < 1){
            n = (int) (1000 * x + 0.5);
            s = Integer.toString (n);
            formatted = "." + s;
        }else if (x < 10){
            n = (int) (100 * x + 0.5);
            s = Integer.toString (n);
            formatted = s.substring(0,1) + "." + s.substring(1,3);
        }else if (x < 100){
            n = (int) (10 * x + 0.5);
            s = Integer.toString (n);
            formatted = s.substring(0,2) + "." + s.substring(2,3);
        }else{
            n = (int) (x + 0.5);
            formatted = Integer.toString (n);
        }
    }catch (StringIndexOutOfBoundsException e){
	formatted = "n/a";
    }
    return formatted;
}

///////////////////////////////////////
//instance method declarations
///////////////////////////////////////

public static String[] benchmarkList (ReportProps props){
    Vector v = new Vector();
    for( int j = 1 ;; j++ ) {
        String name = props.get("spec.benchmarkGroup1."+((j < 10) ? "0" : "")
+ j);
        if( name == null )
            break;
	String weight = props.get ("spec.report." + name + ".weight");
	if (weight != null && ! weight.equals ("0"))
            v.addElement( name );
    }
    int nel = v.size();
    if (nel == 0)
	return new String[0];
    String[] names = new String [nel];
    for (int i=0; i < nel; i++)
	names[i] = (String) v.elementAt(i);
    return names;
}

private void calculate(){
    double productWorst = 1;
    double productBest = 1;
    double weights = 0;
    for (int i=0; i < result.length; i++){
	double wt = result[i].weight;
	double worst = result[i].worstRatio();
	double best = result[i].bestRatio();
	if (worst > 0 && best > 0){
	    productWorst *= Math.pow (worst, wt);
	    productBest  *= Math.pow (best, wt);
	    weights += wt;
	}
	if (worst > highestBase)
	    highestBase = worst;
	if (best > highestPeak)
	    highestPeak = best;
    }
    if (weights > 0){
	baseMetric = Math.pow (productWorst, 1/weights);
	peakMetric = Math.pow (productBest,  1/weights);
    }
}

public String composite(){
    if (valid)
        return "SPECjvm98 = " + format(peakMetric) +
            ", SPECjvm_base98 = " + format(baseMetric);
    else
	return "Invalid Result";
}

public String detail(){
//    String[] name = Result.benchmarkList(props);
    StringBuffer buf = new StringBuffer();
    if (!valid){
	buf.append ("<H4>Invalid Result</H4>\n");
	buf.append ("This result is not valid for the following reason(s):\n");
	buf.append ("<PRE>\n");
	if (! check.valid)
	    buf.append (check.invalidReason.toString());
	if (! runInHarness)
	    buf.append ("It was run from the command line " +
		"instead of as an applet\n");
	if (! runFromHttp)
	    buf.append ("It was not run from a web server\n");
        for (int i=0; i < result.length; i++){
	    buf.append (result[i].invalidReason.toString());
        }
	buf.append ("</PRE>\n");
    }
    buf.append ("<H4>Details of Runs</H4>\n");
    buf.append ("<TABLE BORDER>\n");
    buf.append ("<TR><TH ROWSPAN=2>Benchmark</TH>\n");
    buf.append ("  <TH ROWSPAN=2>Ref. Time</TH>\n");
    buf.append ("  <TH ROWSPAN=2>Run #</TH>\n");
    buf.append ("  <TH ROWSPAN=2>Time (sec)</TH>\n");
    buf.append ("  <TH ROWSPAN=2>Ratio</TH>\n");
    buf.append ("  <TH COLSPAN=2>Used heap (MB)</TH>\n");
    buf.append ("  <TH COLSPAN=2>Total heap (MB)</TH>\n");
    buf.append ("</TR>\n");
    buf.append ("<TR><TH>Start</TH><TH>End</TH>\n");
    buf.append ("    <TH>Start</TH><TH>End</TH></TR>\n");
    for (int i=0; i < result.length; i++){
	buf.append (result[i].toDetailRows());
    }
    buf.append ("</TABLE>\n");
    return buf.toString();
}

private String gifGraph (){
    StringBuffer buf = new StringBuffer();
    buf.append("<TABLE CELLSPACING=0 CELLPADDING=0>\n");
    for (int i=0; i < result.length; i++)
	buf.append (result[i].toBars(highestPeak));
    if (valid)
        buf.append (Result.bars ("G.Mean", baseMetric,
	    peakMetric, highestPeak));
    buf.append("</TABLE>\n");
    return buf.toString();
}

public String javaDetail (String codeBase){
    StringBuffer buf = new StringBuffer();
    buf.append ("<h3>Heap Memory Utilization Graphs</h3>\n" +
	"Used and Total JVM heap at the end of each run<P>\n" +
        "<applet code=\"BasePeakGraph.class\"" +
            " codebase=\"" + codeBase + "\"" +
            " width=" + (2 * maxBarWidth + widthAdj2) +
            " height=500>\n" +
        "<param name=color value=dd4444>\n" +
        "<param name=font value=Helvetica>\n" +
        "<param name=fontsize value=9>\n" +
        "<param name=space  value=3>\n");
    int ip = 0;
    for (int i=0; i < result.length; i++){
        Result r = result[i];
        Run[] run = r.run;
        for (int j=0; j < run.length; j++){
	    buf.append (
	        "<param name=label" + ip + " value=" + r.name + ">\n" +
		"<param name=base" + ip + "  value=" + run[j].usedMemoryEnd + ">\n" +
	        "<param name=peak" + ip + "  value=" + run[j].totalMemoryEnd + ">\n");
	    ip++;
        }
    }
    buf.append ("</applet>\n");
    return buf.toString();
}

private String javaGraph (String codeBase){
    StringBuffer buf = new StringBuffer();
    buf.append ("<p><b>SPEC Ratios</b></p>\n" +
        "<applet code=\"BasePeakGraph.class\"" +
            " codebase=\"" + codeBase + "\"" +
            " width=" + (maxBarWidth + widthAdj1) +
            " height=250>\n" +
        "<param name=color value=dd4444>\n" +
        "<param name=font value=Helvetica>\n" +
        "<param name=fontsize value=12>\n" +
        "<param name=space  value=5>\n" +
	"<param name=digits value=" + digits + ">\n");
    int i;
    for (i=0; i < result.length; i++){
	buf.append ("<param name=label" + i + " value=" +
	    result[i].name + ">\n");
	buf.append ("<param name=base" + i + "  value=" +
	    format (result[i].worstRatio()) + ">\n");
	buf.append ("<param name=peak" + i + "  value=" +
	    format (result[i].bestRatio()) + ">\n");
    }
    if (valid)
        buf.append ("<param name=label" + i + " value=G.Mean>\n" +
            "<param name=base" + i + " value=" + format (baseMetric) + ">\n" +
            "<param name=peak" + i + " value=" + format (peakMetric) + ">\n");
    buf.append ("<!-- For the Java impaired -->\n");
    buf.append (gifGraph());
    buf.append ("</applet>\n");
    return buf.toString();
}

private String ratioOrNa (double x){
    if (!valid || x <= 0)
	return "n/a";
    else
	return format (x);
}

public String tableAndGraph (boolean useJavaGraph, String codeBase){
    StringBuffer buf = new StringBuffer();
    buf.append(
	"<TABLE BORDER WIDTH=\"100%\">\n" +
	"<TR><TH ALIGN=LEFT ROWSPAN=2>Benchmark</TH>\n" +
	"    <TH COLSPAN=2>SPEC ratios</TH>\n"
	);
    int span = result.length + 3;
    buf.append ("    <TH ROWSPAN=" + span + ">\n");
    if (useJavaGraph)
        buf.append (javaGraph (codeBase));
    else
        buf.append (gifGraph());
    buf.append ("</TH></TR>\n");
    buf.append (
	"<TR><TH ALIGN=RIGHT>Worst</TH>\n" +
	"    <TH ALIGN=RIGHT>Best</TH></TR>\n"
	);
    for (int i=0; i < result.length; i++)
	buf.append (result[i].toRow(highestPeak));
    buf.append(
	"<TR><TH ALIGN=LEFT>Geometric Mean</TH>\n" +
	"    <TH ALIGN=RIGHT>" + ratioOrNa (baseMetric) +
	"</TH>\n" +
	"    <TH ALIGN=RIGHT>" + ratioOrNa (peakMetric) +
	"</TH>\n" +
	"</TR>\n</TABLE>\n"
	);
    return buf.toString();
}


} // End Class
