/*
 * @(#)Result.java	1.13 08/07/98
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1997,1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 */

package spec.reporter;

import java.io.*;
import java.text.*;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;
import spec.reporter.Metrics;
import spec.reporter.Run;

public class Result{

///////////////////////////////////////
//class variable field declarations
///////////////////////////////////////
private static double maxBarWidth = 0;
private static DecimalFormat memFormat   = new DecimalFormat ("##.0");

///////////////////////////////////////
//instance variable field declarations
///////////////////////////////////////
private int		best = -1;
private int		digits = 3;
public StringBuffer	invalidReason = new StringBuffer();
public String		name;
//private DecimalFormat	ratioFormat;
public double		referenceTime;
public Run[]		run;
public boolean		valid = true;
public double		weight;
private int		worst = -1;

///////////////////////////////////////
//constructor declarations
///////////////////////////////////////
public Result (String name, ReportProps props){
    this.name = name;
    weight = props.getDouble ("spec.report." + name + ".weight");
    referenceTime = props.getDouble ("spec.report." + name + ".ref");
    if (maxBarWidth <= 0)
        maxBarWidth = props.getDouble ("spec.report.maxBarWidth");
    Vector rv = new Vector(8);
    double bestTime = Double.MAX_VALUE;
    double worstTime = 0;
    for (int i=0; ;i++){
	double t = props.getDouble ("spec.results." + name +
	    ".run" + i + ".time", -1);
	if (t < 0) break;
	Run r = new Run (props, i, t, this);
	rv.addElement(r);
	if (r.time < bestTime){
	    best = i;
	    bestTime = r.time;
	}
	if (r.time > worstTime){
	    worst = i;
	    worstTime = r.time;
	}
    }
    run = new Run[rv.size()];
    if (run.length == 0){
	valid = false;
	invalidReason.append (name + " was not run\n");
    }else{
        for (int i=0; i < run.length; i++)
	    run[i] = (Run) rv.elementAt(i);
    }
}

///////////////////////////////////////
//class method declarations
///////////////////////////////////////

public static String bars (String label, double base, double peak,
    double highest)
{
    StringBuffer buf = new StringBuffer();
    buf.append ("<TR><TD ROWSPAN=2><FONT SIZE=-1>" + label +
        "</FONT></TD>\n");
    int width = (int) (maxBarWidth * peak / highest);
    if (width == 0) width = 1;
    buf.append ("  <TD><IMG SRC=\"images/peakbar.gif\" WIDTH=\"" + width + "\"" +
       " HEIGHT=\"13\" ALIGN=\"MIDDLE\"></TD></TR>\n");
    width = (int) (maxBarWidth * base / highest);
    if (width == 0) width = 1;
    buf.append ("<TR><TD><IMG SRC=\"images/basebar.gif\" WIDTH=\"" + width + "\"" +
       " HEIGHT=\"13\" ALIGN=\"MIDDLE\"></TD></TR>\n");
    return buf.toString();
}

///////////////////////////////////////
//instance method declarations
///////////////////////////////////////

public double bestRatio(){
    if (best < 0)
	return 0;
    else
	return run[best].ratio();
}

public double bestTime(){
    if (best < 0)
	return 0;
    else
	return run[best].time;
}

public double worstRatio(){
    if (run.length <= 0)
	return 0;
    else
	return run[worst].ratio();
}

public double worstTime(){
    if (run.length <= 0)
	return 0;
    else
	return run[worst].time;
}

public String toDetailRows(){
    StringBuffer buf = new StringBuffer("<TR>\n");
    if (run.length == 0){
        buf.append ("  <TD>" +name+ "</TD>\n");
        buf.append ("  <TD COLSPAN=8><I>not run</I></TD>\n");
    }else{
        buf.append ("  <TD VALIGN=TOP ROWSPAN=" + run.length +">" +
	    name + "</TD>\n");
        buf.append ("  <TD VALIGN=TOP ROWSPAN=" + run.length +">" +
	    referenceTime + "</TD>\n");
        buf.append (detailRow(0));
        buf.append ("</TR>\n");
        for (int i=1; i < run.length; i++){
            buf.append ("<TR>\n");
            buf.append (detailRow(i));
            buf.append ("</TR>\n");
        }
    }
    return buf.toString();
}

private String detailRow (int n){
    StringBuffer buf = new StringBuffer();
    buf.append ("  <TD ALIGN=RIGHT>" + n + "</TD>\n");
    buf.append ("  <TD ALIGN=RIGHT>" + 
	Metrics.format (run[n].time) + "</TD>\n");
    buf.append ("  <TD ALIGN=RIGHT>" + 
	Metrics.format (run[n].ratio()) + "</TD>\n");
    buf.append ("  <TD ALIGN=RIGHT>" + 
	memFormat.format(run[n].usedMemoryStart) + "</TD>\n");
    buf.append ("  <TD ALIGN=RIGHT>" + 
	memFormat.format(run[n].usedMemoryEnd) + "</TD>\n");
    buf.append ("  <TD ALIGN=RIGHT>" + 
	memFormat.format(run[n].totalMemoryStart) + "</TD>\n");
    buf.append ("  <TD ALIGN=RIGHT>" + 
	memFormat.format(run[n].totalMemoryEnd) + "</TD>\n");
    return buf.toString();
}

public String toRow (double highest){
    StringBuffer buf = new StringBuffer("<TR>\n");
    buf.append ("  <TD>" + name + "</TD>\n");
    buf.append ("  <TD ALIGN=RIGHT>" + 
	Metrics.format (worstRatio()) + "</TD>\n");
    buf.append ("  <TD ALIGN=RIGHT>" + 
 	Metrics.format (bestRatio()) + "</TD>\n");
    buf.append ("</TR>\n");
    return buf.toString();
}

public String toBars (double highest){
    return bars (name, worstRatio(), bestRatio(), highest);
}

/*
public String toString(){
    StringBuffer buf = new StringBuffer(name + ":\n");
    buf.append ("Reference time: " + referenceTime + "\n");
    buf.append ("Weight: " + weight + "\n");
    buf.append (run.length + " runs\n");
    for (int i=0; i < run.length; i++){
	buf.append ("Run " + i + "\n");
	buf.append (run[i].toString());
    }
    return buf.toString();
}
*/

}
