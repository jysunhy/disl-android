/*
 * @(#)AsciiMetrics.java	1.2 09/14/98
 * Results for all runs of all benchmarks. Use in ASCII-only report
 * Walter Bays
 *
 * Copyright (c) 1998 Standard Performance Evaluation Corporation (SPEC)
 *               All rights reserved.
 * Copyright (c) 1998 Sun Microsystems, Inc. All rights reserved.
 *
 * This source code is provided as is, without any express or implied warranty.
 */

package spec.reporter;

import java.io.*;
import java.text.*;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

public class AsciiMetrics{

///////////////////////////////////////
//class variable field declarations
///////////////////////////////////////
private static int	digits = 3;

private static DecimalFormat memFormat   = new DecimalFormat ("##.0");

///////////////////////////////////////
//instance variable field declarations
///////////////////////////////////////
private double			baseMetric;
private Result			check;
private double			highestBase = 0;
private double			highestPeak = 0;
private String[]		name;
private double			peakMetric;
private ReportProps		props;
private Result[]		result;
private boolean			runFromHttp;
private boolean			runInHarness;
private boolean			useJavaGraph;
public boolean			valid;

///////////////////////////////////////
//constructor declarations
///////////////////////////////////////

public AsciiMetrics (ReportProps props){
    this.props = props;
    check = new Result ("_200_check", props);
    String s = props.get ("spec.results.commandLine");
    runInHarness = s != null && s.equals ("false");
    s = props.get ("spec.initial.cbase");
    runFromHttp = s != null && s.toLowerCase().startsWith ("http:/");
    this.valid = check.valid && runInHarness && runFromHttp;
    name = benchmarkList(props);
    result = new Result [name.length];
    for (int i=0; i<result.length; i++){
	result[i] = new Result (name[i], props);
        this.valid = this.valid && result[i].valid;
    }
    calculate();
}

///////////////////////////////////////
//class method declarations
///////////////////////////////////////

///////////////////////////////////////
//instance method declarations
///////////////////////////////////////

public static String[] benchmarkList (ReportProps props){
    Vector v = new Vector();
    for( int j = 1 ;; j++ ) {
        String name = props.get("spec.benchmarkGroup1."+((j < 10) ? "0" : "")
+ j);
        if( name == null )
            break;
	String weight = props.get ("spec.report." + name + ".weight");
	if (weight != null && ! weight.equals ("0"))
            v.addElement( name );
    }
    int nel = v.size();
    if (nel == 0)
	return new String[0];
    String[] names = new String [nel];
    for (int i=0; i < nel; i++)
	names[i] = (String) v.elementAt(i);
    return names;
}

private void calculate(){
    double productWorst = 1;
    double productBest = 1;
    double weights = 0;
    for (int i=0; i < result.length; i++){
	double wt = result[i].weight;
	double worst = result[i].worstRatio();
	double best = result[i].bestRatio();
	if (worst > 0 && best > 0){
	    productWorst *= Math.pow (worst, wt);
	    productBest  *= Math.pow (best, wt);
	    weights += wt;
	}
	if (worst > highestBase)
	    highestBase = worst;
	if (best > highestPeak)
	    highestPeak = best;
    }
    if (weights > 0){
	baseMetric = Math.pow (productWorst, 1/weights);
	peakMetric = Math.pow (productBest,  1/weights);
    }
}

public String composite(){
    if (valid)
        return "SPECjvm98 = " + Metrics.format(peakMetric) +
            ", SPECjvm_base98 = " + Metrics.format(baseMetric);
    else
	return "Invalid Result";
}

public String detail(){
    StringBuffer buf = new StringBuffer();
    if (!valid){
	buf.append ("*** Invalid Result\n");
	buf.append ("This result is not valid for the following reason(s):\n");
	if (! check.valid)
	    buf.append (check.invalidReason.toString());
	if (! runInHarness)
	    buf.append ("It was run from the command line " +
		"instead of as an applet\n");
	if (! runFromHttp)
	    buf.append ("It was not run from a web server\n");
        for (int i=0; i < result.length; i++){
	    buf.append (result[i].invalidReason.toString());
        }
	buf.append ("\n");
    }
    buf.append ("\n* Details of Runs\n\n");
    buf.append ("                                            " +
	"Used Heap       Total Heap\n");
    TextBlock c1 = new TextBlock (16, "Benchmark");
    TextBlock c2 = new TextBlock (9, "Ref");
    TextBlock c3 = new TextBlock (5, "Run");
    TextBlock c4 = new TextBlock (6, "Sec");
    TextBlock c5 = new TextBlock (8, "Ratio");
    TextBlock c6 = new TextBlock (8, "Start");
    TextBlock c7 = new TextBlock (8, "End");
    TextBlock c8 = new TextBlock (8, "Start");
    TextBlock c9 = new TextBlock (8, "End");
    for (int i=0; i < result.length; i++){
	Result r = result[i];
	c1.add (r.name);
	c2.add (Metrics.format (r.referenceTime));
	if (r.run.length <= 0){
            c3.add ("not run");
            c4.add ("");
            c5.add ("");
            c6.add ("");
            c7.add ("");
            c8.add ("");
            c9.add ("");
	}else{
	    for (int j=0; j < r.run.length; j++){
		if (j > 0){
		    c1.add ("");
		    c2.add ("");
		}
                c3.add (Integer.toString(j));
                c4.add (Metrics.format (r.run[j].time));
                c5.add (Metrics.format (r.run[j].ratio()));
                c6.add (memFormat.format (r.run[j].usedMemoryStart));
                c7.add (memFormat.format (r.run[j].usedMemoryEnd));
                c8.add (memFormat.format (r.run[j].totalMemoryStart));
                c9.add (memFormat.format (r.run[j].totalMemoryEnd));
	    }
	}
    }
    buf.append (c1.join(c2,"").join(c3,"").join(c4,"").join(c5,"").
	join(c6,"").join(c7,"").join(c8,"").join(c9,"").toString());
    return buf.toString();
}

private String ratioOrNa (double x){
    if (!valid || x <= 0)
	return "n/a";
    else
	return Metrics.format (x);
}

public String ratioTable (){
    TextBlock benches = new TextBlock (16, "Benchmark");
    TextBlock base = new TextBlock (10, "Worst");
    TextBlock peak = new TextBlock (10, "Best");
    for (int i=0; i < result.length; i++){
	benches.add (result[i].name);
	base.add (Metrics.format (result[i].worstRatio()));
	peak.add (Metrics.format (result[i].bestRatio()));
    }
    benches.add ("Geometric Mean");
    base.add (ratioOrNa (baseMetric));
    peak.add (ratioOrNa (peakMetric));
    return benches.join(base).join (peak," ").toString();
}


} // End Class
